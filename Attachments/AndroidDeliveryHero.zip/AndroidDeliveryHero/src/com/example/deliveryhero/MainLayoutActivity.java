package com.example.deliveryhero;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class MainLayoutActivity extends Activity {

	private static String TAG = MainLayoutActivity.class.getSimpleName();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d(TAG, "onCreate()");
		setContentView(R.layout.main_layout);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}

	@Override
	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	@Override
	protected void onResume() {

		super.onResume();
		Log.d(TAG, "onResume()");
	}

}
