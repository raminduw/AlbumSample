package com.example.deliveryhero;

public class Hobbies {

	public static final String[] HOBBIES_LIST = { "Cricket", "Movies", "Music", "Travel", "Shopping", "Reading" };

	public static final String[] DESCRIPTION = {
			"Cricket is a bat-and-ball game played between two teams of "
					+ "11 players each on a field at the centre of which is a rectangular 22-yard long pitch."
					+ " Each team takes its turn to bat, attempting to score runs, while the other team fields. "
					+ "Each turn is known as an innings. "
					+ " The bowler delivers the ball to the batsman who "
					+ "attempts to hit the ball with his bat away from the fielders so he can run to the "
					+ "other end of the pitch (which is counted as one run) without getting run out"
					+ "(the event in which the fielder throws the ball directly onto wickets or to a player who is near to wickets so he"
					+ "can dislodge them from the ground before the batsman or the non-striker has reached the crease). Each batsman "
					+ "(the other is called non-striker) continues batting until he is out. The batting team continues batting until ten batsmen are out or "
					+ "specified number of overs (6 countable balls bowled is 1 over) have been bowled, at which point the teams switch roles and the fielding team comes in to bat.",

			"Movies, also known as films, are a type of visual communication which use moving pictures "
					+ "and sound to tell stories or inform (help people to learn). People in every part "
					+ "of the world watch movies as a type of entertainment, a way to have fun. Fun for "
					+ "some people can mean laughing, while for others it can mean crying, or feeling afraid."
					+ " Most movies are made so that they can be shown on big screens at cinemas or movie theatres. "
					+ "After movies are shown on movie screens for a period of time (ranging from a few weeks to several months),"
					+ " movies are shown on pay television or cable television, and sold or rented on DVD disks or videocassette tapes, "
					+ "so that people can watch the movies at home. You can also download or stream movies. Later movies are shown on television stations.",

			"Music is an art form whose medium is sound and silence. Its common elements "
					+ "are pitch (which governs melody and harmony), rhythm (and its associated concepts "
					+ "tempo, meter, and articulation), dynamics, and the sonic qualities of timbre and texture. " +

					" The creation, performance, significance, and even the definition "
					+ " of music vary according to culture and social context. Music ranges from "
					+ "strictly organized compositions (and their recreation in performance), "
					+ " through improvisational music to aleatoric forms. Music can be divided into genres and subgenres,"
					+ " although the dividing lines and relationships between music genres are often subtle, sometimes open "
					+ " to personal interpretation, and occasionally controversial. Within the arts, music may be classified as a"
					+ " performing art, a fine art, and auditory art. It may also be divided among art music and folk music. "
					+ " There is also a strong connection between music and mathematics. Music may be played and heard live,"
					+ " may be part of a dramatic work or film, or may be recorded.",

			"Travel is the movement of people between relatively distant geographical locations, "
					+ "and can involve travel by foot, bicycle, automobile, train, boat, airplane, or other means,"
					+ " with or without luggage, and can be one way or round trip "
					+ "Travel can also include relatively short stays between successive movements",

			"A retailer or shop is a business that presents a selection of goods or services and offers to sell them to "
					+ "customers for money or other goods. Shopping is an activity in which a customer browses the available "
					+ "goods or services presented by one or more retailers with the intent to purchase a suitable selection of "
					+ "them. In some contexts it may be considered a leisure activity as well as an economic one." +

					"A woman shopping at a shopping mall in the United States in December 2005."
					+ "The shopping experience can range from delightful to terrible, based on a "
					+ "variety of factors including how the customer is treated, convenience, the type of goods being purchased, and mood.[1]" +

					"The shopping experience can also be influenced by other shoppers."
					+ "For example, research from a field experiment found that male and female shoppers "
					+ "who were accidentally touched from behind by other shoppers left a store earlier "
					+ "than people who had not been touched and evaluated brands more negatively, resulting in the Accidental Interpersonal Touch effect",

			"Reading is a complex cognitive process of decoding symbols in order to construct "
					+ "or derive meaning (reading comprehension). It is a means of language acquisition,"
					+ " of communication, and of sharing information and ideas. Like all language, it is a"
					+ " complex interaction between the text and the reader which is shaped by the reader�s prior "
					+ "knowledge, experiences, attitude, and language community which is culturally and socially "
					+ "situated. The reading process requires continuous practice, development, and refinement. "
					+ "In addition, reading requires creativity and critical analysis. Consumers of"
					+ " literature make ventures with each piece, innately deviating from literal words to "
					+ "create images that make sense to them in the unfamiliar places the texts describe. "
					+ "Because reading is such a complex process, it cannot be controlled or restricted to one "
					+ "or two interpretations. There are no concrete laws in reading, but rather allows readers "
					+ "an escape to produce their own products introspectively" };
}
