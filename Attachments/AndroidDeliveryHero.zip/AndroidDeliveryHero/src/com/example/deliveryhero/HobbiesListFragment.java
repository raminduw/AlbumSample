package com.example.deliveryhero;

import android.app.FragmentTransaction;
import android.app.ListFragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class HobbiesListFragment extends ListFragment {
	private static String TAG = HobbiesListFragment.class.getSimpleName();
	private boolean isDualPane;
	private int currentPosition = 0;

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		Log.d(TAG, "onActivityCreated()");

		setListAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_activated_1, Hobbies.HOBBIES_LIST));

		View detailsFrame = getActivity().findViewById(R.id.details);
		isDualPane = detailsFrame != null && detailsFrame.getVisibility() == View.VISIBLE;

		if (savedInstanceState != null) {
			currentPosition = savedInstanceState.getInt("selectedItem", 0);
		}

		if (isDualPane) {
			getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);
			showHobbyDetails(currentPosition);
		}
	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putInt("selectedItem", currentPosition);
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		showHobbyDetails(position);
	}

	private void showHobbyDetails(int index) {
		currentPosition = index;
		if (isDualPane) {
			getListView().setItemChecked(index, true);

			DetailsFragment details = (DetailsFragment) getFragmentManager().findFragmentById(R.id.details);
			if (details == null || details.getShownIndex() != index) {
				details = DetailsFragment.newInstance(index);
				FragmentTransaction ft = getFragmentManager().beginTransaction();
				ft.replace(R.id.details, details);
				ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
				ft.commit();
			}

		} else {
			Intent intent = new Intent();
			intent.setClass(getActivity(), DetailsActivity.class);
			intent.putExtra("index", index);
			startActivity(intent);
		}
	}
}
