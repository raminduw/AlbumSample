package com.album.sample.utils;

import java.util.ArrayList;


import android.app.ListFragment;
import android.os.Bundle;

public class ItemsSongsList extends ListFragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Generate a list of 1000 dummy items
        ArrayList<Item> dummies = new ArrayList<Item>();
        for (int i = 0; i < 1000; i++){
            Item item = new Item();
			item.setMainHeader("Songs " + i);
            item.setSecondaryHeader("Gender " + i);
            dummies.add(item);
        }

        ItemsAdapter adapter = new ItemsAdapter(dummies, getActivity());
        setListAdapter(adapter);
    }
}
